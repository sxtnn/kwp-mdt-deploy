#!/usr/bin/env python3
"""KWP MDT static + same-origin sync API (works all browsers)."""
import json, os, threading, time
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlparse

ROOT = os.path.dirname(os.path.abspath(__file__))
DATA_FILE = os.path.join(ROOT, "mdt_cloud_data.json")
LOCK = threading.Lock()

def load():
    try:
        with open(DATA_FILE, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return {"mdt": True, "v": 1, "rooms": {}}

def save(data):
    tmp = DATA_FILE + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, separators=(",", ":"))
    os.replace(tmp, DATA_FILE)

class Handler(SimpleHTTPRequestHandler):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, directory=ROOT, **kwargs)

    def log_message(self, fmt, *args):
        pass

    def _cors(self):
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, PUT, POST, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type")
        self.send_header("Cache-Control", "no-store")

    def do_OPTIONS(self):
        self.send_response(204)
        self._cors()
        self.end_headers()

    def do_GET(self):
        p = urlparse(self.path)
        if p.path in ("/api/sync", "/api/data"):
            with LOCK:
                data = load()
            body = json.dumps(data, ensure_ascii=False).encode("utf-8")
            self.send_response(200)
            self.send_header("Content-Type", "application/json; charset=utf-8")
            self._cors()
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)
            return
        if p.path in ("/", "/index.html"):
            self.path = "/MDT-Policja.html"
        return SimpleHTTPRequestHandler.do_GET(self)

    def do_PUT(self):
        return self._write()

    def do_POST(self):
        return self._write()

    def _write(self):
        p = urlparse(self.path)
        if p.path not in ("/api/sync", "/api/data"):
            self.send_error(404)
            return
        n = int(self.headers.get("Content-Length") or 0)
        raw = self.rfile.read(n) if n else b"{}"
        try:
            incoming = json.loads(raw.decode("utf-8") or "{}")
        except Exception:
            self.send_error(400, "bad json")
            return
        with LOCK:
            # full replace of payload (client does room merge)
            if isinstance(incoming, dict):
                incoming["updatedAt"] = int(time.time() * 1000)
                save(incoming)
                data = incoming
            else:
                data = load()
        body = json.dumps({"ok": True, "updatedAt": data.get("updatedAt")}, ensure_ascii=False).encode("utf-8")
        self.send_response(200)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self._cors()
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

if __name__ == "__main__":
    if not os.path.exists(DATA_FILE):
        save({"mdt": True, "v": 1, "rooms": {}})
    port = int(os.environ.get("PORT", "8765"))
    httpd = ThreadingHTTPServer(("0.0.0.0", port), Handler)
    print("KWP MDT server on :%s" % port, flush=True)
    httpd.serve_forever()
